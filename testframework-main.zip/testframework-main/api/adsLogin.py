import  requests

def login():
    data = {
        "username": "wangmenghu@kuaishou.com",
        "password": "wmh@19891203"
    }


